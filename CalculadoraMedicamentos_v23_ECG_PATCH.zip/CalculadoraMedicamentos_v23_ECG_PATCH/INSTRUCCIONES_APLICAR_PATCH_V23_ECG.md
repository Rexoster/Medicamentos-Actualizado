# Instrucciones para aplicar el parche v23 ECG

Base requerida:

- `CalculadoraMedicamentosNativa_v22_1_tabla_limpia.zip`

## Opción rápida

1. Descomprime tu proyecto actual.
2. Copia la carpeta `CalculadoraMedicamentosNativa` de este parche encima de la carpeta raíz de tu proyecto.
3. Acepta reemplazar archivos cuando el sistema lo pida.
4. Compila desde Android Studio o con:

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

## Opción con diff

Desde la carpeta que contiene `CalculadoraMedicamentosNativa`, ejecuta:

```bash
patch -p0 < parche_v23_ecg.diff
```

## Qué cambia

- Agrega el módulo **ECG** al menú principal.
- Agrega motor clínico para FC/RR, QTc, eje, HVI y ST.
- Agrega pantalla Compose para el analizador y calculadoras.
- Actualiza `version.properties` a `VERSION_CODE=36` y `VERSION_NAME=3.16.0-native`.

## Verificación sugerida

```bash
python3 scripts/preflight_source_checks.py
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

Nota: en el entorno donde se generó el parche no se pudo ejecutar Gradle completo porque el wrapper intentó descargar Gradle y no había acceso a internet. Sí se ejecutó el preflight local y una prueba rápida del motor ECG con `kotlinc`.
